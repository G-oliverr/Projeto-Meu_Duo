package com.example.meuduo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.HashMap;
import java.util.Map;

public class telaSala extends AppCompatActivity {

    private DatabaseReference chatRef;
    private FirebaseRecyclerAdapter<Map<String, Object>, RecyclerView.ViewHolder> adapter;
    private EditText editTextMessage;
    private Button btnEnviarMensagem;
    private FirebaseFirestore db;

    private String salaId;
    private String idUsuarioCriador;

    private TextView textViewNomeSala;
    private TextView textViewNomeUsuarioCriador;
    private Button btnFecharSala;

    private ListenerRegistration salaListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_sala);

        chatRef = FirebaseDatabase.getInstance().getReference("chat");
        db = FirebaseFirestore.getInstance();

        salaId = getIntent().getStringExtra("salaId");

        textViewNomeSala = findViewById(R.id.textViewNomeSala);
        textViewNomeUsuarioCriador = findViewById(R.id.textViewNomeUsuarioCriador);
        btnFecharSala = findViewById(R.id.btnFecharSala);
        editTextMessage = findViewById(R.id.editTextMessage);
        btnEnviarMensagem = findViewById(R.id.buttonSendMessage);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewChat);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FirebaseRecyclerOptions<Map<String, Object>> options =
                new FirebaseRecyclerOptions.Builder<Map<String, Object>>()
                        .setQuery(chatRef.child(salaId), snapshot -> (Map<String, Object>) snapshot.getValue())
                        .build();

        adapter = new FirebaseRecyclerAdapter<Map<String, Object>, RecyclerView.ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position, @NonNull Map<String, Object> model) {
                TextView textViewSender = holder.itemView.findViewById(R.id.textViewSender);
                TextView textViewContent = holder.itemView.findViewById(R.id.textViewContent);

                String sender = (String) model.get("userName");
                String content = (String) model.get("content");

                textViewSender.setText(sender);
                textViewContent.setText(content);
            }

            @NonNull
            @Override
            public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_message, parent, false);
                return new RecyclerView.ViewHolder(view) {};
            }
        };

        recyclerView.setAdapter(adapter);

        btnEnviarMensagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enviarMensagem();
            }
        });

        btnFecharSala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                excluirSala();
            }
        });

        salaListener = db.collection("salas").document(salaId)
                .addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            Log.e("telaSala", "Erro ao ouvir alterações na sala", error);
                            return;
                        }

                        if (value != null && value.exists()) {
                            boolean salaFechada = value.getBoolean("fechada");
                            if (salaFechada) {
                                exibirMensagemSalaFechada();
                                setResult(RESULT_OK);
                                finish();
                            } else {
                                String nomeSala = value.getString("nomeSala");
                                idUsuarioCriador = value.getString("idUsuarioCriador");

                                textViewNomeSala.setText(nomeSala);
                                obterNomeUsuario(idUsuarioCriador, new NomeUsuarioCallback() {
                                    @Override
                                    public void onNomeUsuarioObtido(String nomeUsuario) {
                                        textViewNomeUsuarioCriador.setText("Criada por: " + nomeUsuario);
                                    }

                                    @Override
                                    public void onFalhaObterNomeUsuario() {
                                        Log.e("telaSala", "Falha ao obter o nome do usuário");
                                    }
                                });
                                habilitarBotaoFechar(idUsuarioCriador);
                            }
                        }
                    }
                });
    }

    private void excluirSala() {
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (usuarioAtual != null && usuarioAtual.getUid().equals(idUsuarioCriador)) {
            db.collection("salas").document(salaId)
                    .update("fechada", true)
                    .continueWithTask(task -> {
                        // Após a atualização do campo "fechada", exclua o documento
                        if (task.isSuccessful()) {
                            return db.collection("salas").document(salaId).delete();
                        } else {
                            throw task.getException(); // Lança a exceção se a atualização falhar
                        }
                    })
                    .addOnSuccessListener(aVoid -> {
                        exibirMensagemSalaFechada();
                        setResult(RESULT_OK);
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        Log.e("telaSala", "Falha ao excluir a sala", e);
                        // Trate falhas ao excluir a sala, se necessário
                    });
        } else {
            // Se o usuário atual não estiver autenticado ou não for o criador da sala,
            // você pode lidar com isso de acordo com seus requisitos
        }
    }


    private void exibirMensagemSalaFechada() {
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (usuarioAtual != null && !usuarioAtual.getUid().equals(idUsuarioCriador)) {
            Toast.makeText(this, "A sala foi fechada pelo criador.", Toast.LENGTH_LONG).show();
        }
    }

    private void obterNomeUsuario(String idUsuario, NomeUsuarioCallback callback) {
        db.collection("usuarios").document(idUsuario)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document != null && document.exists()) {
                            String nomeUsuario = document.getString("usuario");
                            callback.onNomeUsuarioObtido(nomeUsuario);
                        } else {
                            callback.onFalhaObterNomeUsuario();
                        }
                    } else {
                        callback.onFalhaObterNomeUsuario();
                    }
                });
    }

    private void habilitarBotaoFechar(String idUsuarioCriador) {
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (usuarioAtual != null) {
            String idUsuarioAtual = usuarioAtual.getUid();

            if (idUsuarioAtual.equals(idUsuarioCriador)) {
                btnFecharSala.setVisibility(View.VISIBLE);
            } else {
                btnFecharSala.setVisibility(View.GONE);
            }
        } else {
            btnFecharSala.setVisibility(View.GONE);
        }
    }

    private void enviarMensagem() {
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();
        String mensagem = editTextMessage.getText().toString().trim();

        if (usuarioAtual != null && !mensagem.isEmpty()) {
            String idUsuario = usuarioAtual.getUid();

            obterNomeUsuario(idUsuario, new NomeUsuarioCallback() {
                @Override
                public void onNomeUsuarioObtido(String nomeUsuario) {
                    Map<String, Object> chatMessage = new HashMap<>();
                    chatMessage.put("idUsuario", idUsuario);
                    chatMessage.put("userName", nomeUsuario);
                    chatMessage.put("content", mensagem);
                    chatMessage.put("timestamp", System.currentTimeMillis());

                    chatRef.child(salaId).push().setValue(chatMessage);
                    editTextMessage.setText("");
                }

                @Override
                public void onFalhaObterNomeUsuario() {
                    Toast.makeText(telaSala.this, "Falha ao obter o nome do usuário", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (salaListener != null) {
            salaListener.remove();
        }
    }

    public interface NomeUsuarioCallback {
        void onNomeUsuarioObtido(String nomeUsuario);
        void onFalhaObterNomeUsuario();
    }
}
