package com.example.meuduo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class telaLobby extends AppCompatActivity {

    private static final int REQUEST_CODE_CRIAR_SALA = 1;
    private FirebaseFirestore db;
    private ListView listViewSalas;
    private TextView textViewMensagem;
    private Button btnCriarSala;
    private String nomeUsuario;
    private ArrayAdapter<String> adapter;
    private Set<String> idSalas; // Lista para armazenar os IDs das salas
    private Handler handler = new Handler();
    private static final long INTERVALO_ATUALIZACAO = 1000; // 1 segundo (em milissegundos)

    private Runnable atualizarSalasTask = new Runnable() {
        @Override
        public void run() {
            atualizarListaSalas();
            handler.postDelayed(this, INTERVALO_ATUALIZACAO);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_lobby);

        db = FirebaseFirestore.getInstance();
        listViewSalas = findViewById(R.id.listViewSalas);
        textViewMensagem = findViewById(R.id.textViewMensagem);
        btnCriarSala = findViewById(R.id.btnCriarSala);
        nomeUsuario = getIntent().getStringExtra("nomeUsuario");

        textViewMensagem.setText("Bem-vindo, " + nomeUsuario + "!");

        adapter = new ArrayAdapter<>(
                telaLobby.this,
                android.R.layout.simple_list_item_1,
                new ArrayList<>()
        );
        listViewSalas.setAdapter(adapter);

        idSalas = new HashSet<>();

        btnCriarSala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exibirDialogCriarSala(); // Chamamos o método para exibir o diálogo
            }
        });

        listViewSalas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String salaId = idSalas.toArray(new String[0])[position];

                // Inicia a telaSala, passando o ID da sala
                Intent intent = new Intent(telaLobby.this, telaSala.class);
                intent.putExtra("salaId", salaId);
                startActivityForResult(intent, REQUEST_CODE_CRIAR_SALA);
            }
        });

        // Inicie a atualização automática
        handler.postDelayed(atualizarSalasTask, INTERVALO_ATUALIZACAO);
    }

    private void exibirDialogCriarSala() {
        // Inflamos o layout do diálogo
        View dialogView = getLayoutInflater().inflate(R.layout.dialogo_criar_sala, null);

        // Criamos o AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView)
                .setTitle("Criar Sala")
                .setPositiveButton("Concluir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        criarSala(dialogView);
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Cancela a criação da sala
                    }
                });

        // Exibimos o diálogo
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void criarSala(View dialogView) {
        EditText editTextNomeSala = dialogView.findViewById(R.id.editTextNomeSala);
        String nomeSala = editTextNomeSala.getText().toString();

        // Adiciona a sala ao Firestore com o nome do usuário
        adicionarSalaNoFirestore(nomeUsuario, nomeSala);
    }

    private void adicionarSalaNoFirestore(final String nomeUsuario, final String nomeSala) {
        // Consulta o Firestore para obter o ID do usuário criador
        db.collection("usuarios")
                .whereEqualTo("usuario", nomeUsuario)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful() && task.getResult() != null && !task.getResult().isEmpty()) {
                            // Assume que há apenas um usuário com o mesmo nome de usuário
                            DocumentSnapshot usuarioDocument = task.getResult().getDocuments().get(0);
                            final String idUsuarioCriador = usuarioDocument.getId();

                            // Adiciona a sala ao Firestore usando um mapa
                            Map<String, Object> salaMap = new HashMap<>();
                            salaMap.put("nomeSala", nomeSala);
                            salaMap.put("idUsuarioCriador", idUsuarioCriador);
                            salaMap.put("dataCriacao", FieldValue.serverTimestamp()); // Adiciona a data de criação
                            salaMap.put("fechada", false); // Adiciona o status da sala (inicialmente não fechada)

                            db.collection("salas")
                                    .add(salaMap)
                                    .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentReference> task) {
                                            if (task.isSuccessful()) {
                                                // A sala foi adicionada com sucesso ao Firestore

                                                // Obtém o ID do documento recém-criado
                                                String salaId = task.getResult().getId();

                                                // Adiciona a nova sala à lista
                                                idSalas.add(salaId);
                                                adapter.add(nomeSala);
                                                adapter.notifyDataSetChanged();

                                                // Inicia a atividade da sala, passando o nome da sala, o ID e o nome do usuário
                                                Intent intent = new Intent(telaLobby.this, telaSala.class);
                                                intent.putExtra("nomeSala", nomeSala);
                                                intent.putExtra("salaId", salaId);
                                                intent.putExtra("nomeUsuarioCriador", nomeUsuario);
                                                startActivityForResult(intent, REQUEST_CODE_CRIAR_SALA);
                                            } else {
                                                // Trate os erros ao adicionar a sala
                                                Log.e("AdicionarSala", "Erro ao adicionar a sala", task.getException());
                                            }
                                        }
                                    });
                        } else {
                            // Trate os erros na consulta do usuário
                            Toast.makeText(telaLobby.this, "Erro ao obter ID do usuário criador: Usuário não encontrado", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void atualizarListaSalas() {
        db.collection("salas")
                .orderBy("dataCriacao", Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            List<String> nomesSalas = new ArrayList<>();
                            Set<String> novasSalas = new HashSet<>();

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String nomeSala = document.getString("nomeSala");
                                String salaId = document.getId();
                                boolean salaFechada = document.getBoolean("fechada");

                                if (nomeSala != null) {
                                    novasSalas.add(salaId);

                                    // Verifica se a sala foi fechada
                                    if (salaFechada && idSalas.contains(salaId)) {
                                        // Remove a sala fechada da lista
                                        idSalas.remove(salaId);
                                        nomesSalas.remove(nomeSala);
                                    } else if (!salaFechada) {
                                        // Adiciona salas não fechadas à lista
                                        nomesSalas.add(nomeSala);
                                    }
                                }
                            }

                            // Remove salas que não estão mais presentes
                            Set<String> salasRemovidas = new HashSet<>(idSalas);
                            salasRemovidas.removeAll(novasSalas);

                            for (String salaRemovida : salasRemovidas) {
                                adapter.remove(salaRemovida);
                            }

                            // Adiciona novas salas
                            adapter.clear();
                            adapter.addAll(nomesSalas);
                            idSalas = novasSalas;
                        } else {
                            Log.e("FirestoreQuery", "Erro ao obter salas", task.getException());
                        }
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_CRIAR_SALA && resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("salaFechada")) {
                boolean salaFechada = data.getBooleanExtra("salaFechada", false);

                if (salaFechada) {
                    Toast.makeText(this, "A sala foi fechada pelo criador.", Toast.LENGTH_SHORT).show();
                    // Adicione aqui qualquer lógica adicional que desejar ao fechar a sala
                    // Por exemplo, retornar à tela de lobby
                    Intent intent = new Intent(telaLobby.this, telaLobby.class);
                    startActivity(intent);
                    finish(); // Encerra a tela da sala
                }
            }
        }
    }
}
