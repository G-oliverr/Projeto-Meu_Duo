package com.example.meuduo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.HashMap;
import java.util.Map;

public class telaCadastro extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private EditText etUsuario, etEmail, etSenha, etDataNascimento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);

        // Inicializar o Firebase Authentication
        FirebaseApp.initializeApp(this);
        mAuth = FirebaseAuth.getInstance();

        // Inicializar o Firebase Firestore
        db = FirebaseFirestore.getInstance();

        // Inicializar Views
        etUsuario = findViewById(R.id.usuario);
        etEmail = findViewById(R.id.editTextTextEmailAddress);
        etSenha = findViewById(R.id.editTextTextPassword);
        etDataNascimento = findViewById(R.id.date);

        // Botão "CADASTRAR"
        Button btnCadastrar = findViewById(R.id.buttonCadastrar);
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastrarUsuario();
            }
        });
    }

    private void cadastrarUsuario() {
        // Obter dados dos EditTexts
        String usuario = etUsuario.getText().toString();
        String email = etEmail.getText().toString();
        String senha = etSenha.getText().toString();
        String dataNascimento = etDataNascimento.getText().toString();

        // Validar entrada (adapte conforme necessário)
        if (usuario.isEmpty() || email.isEmpty() || senha.isEmpty() || dataNascimento.isEmpty()) {
            Toast.makeText(telaCadastro.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar se o e-mail já está registrado
        verificarEmailExistente(email, new OnEmailVerificationListener() {
            @Override
            public void onResult(boolean emailExistente) {
                if (emailExistente) {
                    Toast.makeText(telaCadastro.this, "Este e-mail já está em uso", Toast.LENGTH_SHORT).show();
                } else {
                    // Criar um mapa para representar os dados do usuário
                    Map<String, Object> dadosUsuario = new HashMap<>();
                    dadosUsuario.put("usuario", usuario);
                    dadosUsuario.put("email", email);
                    dadosUsuario.put("senha", senha);  // Salvar a senha para criar a conta no Firebase Authentication
                    dadosUsuario.put("dataNascimento", dataNascimento);

                    // Adicionar os dados a uma coleção chamada "usuarios"
                    db.collection("usuarios")
                            .add(dadosUsuario)
                            .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentReference> task) {
                                    if (task.isSuccessful()) {
                                        // Cadastro no Firestore realizado com sucesso
                                        // Criar conta no Firebase Authentication
                                        criarContaFirebase(email, senha);
                                    } else {
                                        // Falha no cadastro no Firestore
                                        Toast.makeText(telaCadastro.this, "Falha no cadastro", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });
    }

    private void criarContaFirebase(String email, String senha) {
        mAuth.createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Conta no Firebase Authentication criada com sucesso
                            Toast.makeText(telaCadastro.this, "Cadastro realizado com sucesso", Toast.LENGTH_SHORT).show();
                            abrirTelaInicio();
                        } else {
                            // Falha na criação da conta no Firebase Authentication
                            Toast.makeText(telaCadastro.this, "Falha na criação da conta no Firebase Authentication", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void abrirTelaInicio() {
        Intent intent = new Intent(this, telaInicio.class);
        startActivity(intent);
        finish();  // Fecha a tela de cadastro para evitar o retorno à mesma pressionando o botão "Voltar"
    }

    private void verificarEmailExistente(String email, OnEmailVerificationListener listener) {
        // Verificar se o e-mail já está registrado no Firestore
        db.collection("usuarios")
                .whereEqualTo("email", email)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            boolean emailExistente = !task.getResult().isEmpty();
                            listener.onResult(emailExistente);
                        } else {
                            // Lidar com falha na verificação
                            listener.onResult(false);
                        }
                    }
                });
    }

    interface OnEmailVerificationListener {
        void onResult(boolean emailExistente);
    }
}
