package com.example.meuduo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class telaLobby extends AppCompatActivity {

    private static final int REQUEST_CODE_CRIAR_SALA = 1;
    private FirebaseFirestore db;
    private ListView listViewSalas;
    private TextView textViewMensagem;
    private Button btnCriarSala;
    private String nomeUsuario;
    private ArrayAdapter<String> adapter;
    private Set<String> idSalas;
    private Handler handler = new Handler();
    private static final long INTERVALO_ATUALIZACAO = 1000;

    private Runnable atualizarSalasTask = new Runnable() {
        @Override
        public void run() {
            atualizarListaSalas();
            handler.postDelayed(this, INTERVALO_ATUALIZACAO);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_lobby);

        db = FirebaseFirestore.getInstance();
        listViewSalas = findViewById(R.id.listViewSalas);
        textViewMensagem = findViewById(R.id.textViewMensagem);
        btnCriarSala = findViewById(R.id.btnCriarSala);
        nomeUsuario = getIntent().getStringExtra("nomeUsuario");

        textViewMensagem.setText("Bem-vindo, " + nomeUsuario + "!");

        adapter = new ArrayAdapter<>(
                telaLobby.this,
                R.layout.item_lista_sala,
                new ArrayList<>()
        );
        listViewSalas.setAdapter(adapter);

        idSalas = new HashSet<>();

        btnCriarSala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exibirDialogCriarSala();
            }
        });

        listViewSalas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String salaId = idSalas.toArray(new String[0])[position];
                abrirSala(salaId);
            }
        });


        handler.postDelayed(atualizarSalasTask, INTERVALO_ATUALIZACAO);
    }

    private void exibirDialogCriarSala() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialogo_criar_sala, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.AlertDialogButtonStyle));

        builder.setView(dialogView);

        builder.setPositiveButton("Concluir", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                criarSala(dialogView);
            }
        }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Cancela a criação da sala
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        // Personalize a cor do texto dos botões após mostrar o AlertDialog
        Button positiveButton = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
        Button negativeButton = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);

        if (positiveButton != null && negativeButton != null) {
            positiveButton.setTextColor(getResources().getColor(R.color.white));
            negativeButton.setTextColor(getResources().getColor(R.color.white));
        }
    }

    private void criarSala(View dialogView) {
        EditText editTextNomeSala = dialogView.findViewById(R.id.editTextNomeSala);
        EditText editTextJogoInteresse = dialogView.findViewById(R.id.editTextJogoInteresse);
        String nomeSala = editTextNomeSala.getText().toString();
        String jogoInteresse = editTextJogoInteresse.getText().toString();

        if (nomeSala.trim().isEmpty()) {
            Toast.makeText(this, "O nome da sala não pode ser vazio", Toast.LENGTH_SHORT).show();
            return;
        }

        adicionarSalaNoFirestore(nomeUsuario, nomeSala, jogoInteresse);
    }

    private void adicionarSalaNoFirestore(final String nomeUsuario, final String nomeSala, final String jogoInteresse) {
        db.collection("usuarios")
                .whereEqualTo("usuario", nomeUsuario)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful() && task.getResult() != null && !task.getResult().isEmpty()) {
                            DocumentSnapshot usuarioDocument = task.getResult().getDocuments().get(0);
                            final String idUsuarioCriador = usuarioDocument.getId();

                            Map<String, Object> salaMap = new HashMap<>();
                            salaMap.put("nomeSala", nomeSala);
                            salaMap.put("jogoInteresse", jogoInteresse);
                            salaMap.put("idUsuarioCriador", idUsuarioCriador);
                            salaMap.put("dataCriacao", FieldValue.serverTimestamp());
                            salaMap.put("fechada", false);

                            db.collection("salas")
                                    .add(salaMap)
                                    .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentReference> task) {
                                            if (task.isSuccessful()) {
                                                String salaId = task.getResult().getId();

                                                idSalas.add(salaId);
                                                adapter.add(nomeSala + "\n" + jogoInteresse);
                                                adapter.notifyDataSetChanged();

                                                abrirSala(salaId);
                                            } else {
                                                Log.e("AdicionarSala", "Erro ao adicionar a sala", task.getException());
                                            }
                                        }
                                    });
                        } else {
                            Toast.makeText(telaLobby.this, "Erro ao obter ID do usuário criador: Usuário não encontrado", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void atualizarListaSalas() {
        db.collection("salas")
                .orderBy("dataCriacao", Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            List<String> salasInfo = new ArrayList<>();
                            List<String> idsSalasOrdenados = new ArrayList<>();

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String nomeSala = document.getString("nomeSala");
                                String jogoInteresse = document.getString("jogoInteresse");
                                String salaId = document.getId();
                                boolean salaFechada = document.getBoolean("fechada");

                                if (nomeSala != null && jogoInteresse != null) {
                                    // Adiciona o ID da sala ao array ordenado
                                    idsSalasOrdenados.add(salaId);

                                    if (salaFechada && idSalas.contains(salaId)) {
                                        idSalas.remove(salaId);
                                        salasInfo.remove(nomeSala);
                                    } else if (!salaFechada) {
                                        salasInfo.add(nomeSala + "\n" + jogoInteresse);
                                    }
                                }
                            }

                            // Remove salas removidas do adapter
                            Set<String> salasRemovidas = new HashSet<>(idSalas);
                            salasRemovidas.removeAll(new HashSet<>(idsSalasOrdenados));

                            for (String salaRemovida : salasRemovidas) {
                                adapter.remove(salaRemovida);
                            }

                            // Limpa o adapter e adiciona os novos nomes
                            adapter.clear();
                            adapter.addAll(salasInfo);

                            // Atualiza idSalas com os IDs das salas ordenadas
                            idSalas = new LinkedHashSet<>(idsSalasOrdenados);

                        } else {
                            Log.e("FirestoreQuery", "Erro ao obter salas", task.getException());
                        }
                    }
                });
    }



    private void abrirSala(String salaId) {
        Intent intent = new Intent(telaLobby.this, telaSala.class);
        intent.putExtra("salaId", salaId);
        startActivityForResult(intent, REQUEST_CODE_CRIAR_SALA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_CRIAR_SALA && resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("salaFechada")) {
                boolean salaFechada = data.getBooleanExtra("salaFechada", false);

                if (salaFechada) {
                    Toast.makeText(this, "A sala foi fechada pelo criador.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(telaLobby.this, telaLobby.class);
                    startActivity(intent);
                    finish();
                }
            }
        }
    }
}