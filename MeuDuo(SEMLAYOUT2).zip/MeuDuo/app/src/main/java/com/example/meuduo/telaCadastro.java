package com.example.meuduo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class telaCadastro extends AppCompatActivity {

    private EditText editTextUsuario, editTextEmailCadastro, editTextSenhaCadastro, editTextDataNascimento;
    private Button btnCadastrar;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);

        // Inicializando as Views
        editTextUsuario = findViewById(R.id.editTextUsuario);
        editTextEmailCadastro = findViewById(R.id.editTextEmailCadastro);
        editTextSenhaCadastro = findViewById(R.id.editTextSenhaCadastro);
        editTextDataNascimento = findViewById(R.id.editTextDataNascimento);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        // Inicializando o FirebaseAuth
        mAuth = FirebaseAuth.getInstance();

        // Inicializando o FirebaseFirestore
        db = FirebaseFirestore.getInstance();

        // Configurando o clique do botão de cadastrar
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Coloque aqui a lógica para cadastrar o usuário
                cadastrarUsuario();
            }
        });
    }

    private void cadastrarUsuario() {
        String email = editTextEmailCadastro.getText().toString();
        String senha = editTextSenhaCadastro.getText().toString();
        String usuario = editTextUsuario.getText().toString();
        String dataNascimento = editTextDataNascimento.getText().toString();

        if (email.isEmpty() || senha.isEmpty() || usuario.isEmpty() || dataNascimento.isEmpty()) {
            // Verifique se todos os campos estão preenchidos
            // Você pode exibir uma mensagem de erro ou fazer algo adequado ao seu aplicativo
            return;
        }

        // Verifique se a data de nascimento está em um formato válido
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        try {
            Date date = dateFormat.parse(dataNascimento);
            // Faça algo com a data, se necessário
        } catch (ParseException e) {
            // A data não está no formato correto
            // Exiba uma mensagem de erro ou faça algo adequado ao seu aplicativo
            return;
        }

        // Verifique se não há mais de uma conta com o mesmo email
        mAuth.createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Cadastro bem-sucedido
                            FirebaseUser user = mAuth.getCurrentUser();

                            // Salvar dados adicionais no Firestore
                            salvarDadosUsuario(user.getUid(), usuario, email, dataNascimento);

                            // Você pode redirecionar para a próxima atividade ou executar outras ações aqui
                            voltarParaTelaInicio();
                        } else {
                            // Se falhar, exiba uma mensagem ou lide com o erro
                            // task.getException() contém detalhes sobre o erro
                            Toast.makeText(telaCadastro.this, "Falha no cadastro: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void salvarDadosUsuario(String userId, String usuario, String email, String dataNascimento) {
        // Crie um Map com os dados do usuário
        Map<String, Object> userData = new HashMap<>();
        userData.put("usuario", usuario);
        userData.put("email", email);
        userData.put("dataNascimento", dataNascimento);

        // Salve os dados no Firestore
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("usuarios").document(userId)
                .set(userData)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(telaCadastro.this, "Dados do usuário salvos com sucesso no Firestore", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(telaCadastro.this, "Falha ao salvar dados do usuário no Firestore", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void voltarParaTelaInicio() {
        Intent intent = new Intent(this, telaInicio.class);
        startActivity(intent);
        finish(); // Isso evita que o usuário retorne para esta tela pressionando o botão de voltar
    }
}
