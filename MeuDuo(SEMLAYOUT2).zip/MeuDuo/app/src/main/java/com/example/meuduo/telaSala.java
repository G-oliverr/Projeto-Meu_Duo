package com.example.meuduo;

import android.os.Bundle;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;

public class telaSala extends AppCompatActivity {

    private FirebaseFirestore db;
    private ListenerRegistration salaListener;
    private String salaId;

    private TextView textViewNomeSala;
    private TextView textViewNomeUsuarioCriador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_sala); // Substitua pelo ID correto

        db = FirebaseFirestore.getInstance();
        salaId = getIntent().getStringExtra("salaId");

        textViewNomeSala = findViewById(R.id.textViewNomeSala); // Substitua pelo ID correto
        textViewNomeUsuarioCriador = findViewById(R.id.textViewNomeUsuarioCriador); // Substitua pelo ID correto

        // Adiciona um listener para atualizar os dados da sala
        salaListener = db.collection("salas").document(salaId)
                .addSnapshotListener(this, (value, error) -> {
                    if (error != null) {
                        // Trate os erros aqui
                        return;
                    }

                    if (value != null && value.exists()) {
                        // Atualiza os TextViews com os dados da sala
                        String nomeSala = value.getString("nomeSala");
                        String idUsuarioCriador = value.getString("idUsuarioCriador");

                        textViewNomeSala.setText(nomeSala);

                        // Obtém o nome do usuário criador
                        obterNomeUsuario(idUsuarioCriador);
                    }
                });
    }

    private void obterNomeUsuario(String idUsuario) {
        db.collection("usuarios").document(idUsuario)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            String nomeUsuarioCriador = document.getString("usuario");
                            textViewNomeUsuarioCriador.setText("Criada por: " + nomeUsuarioCriador);
                        }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove o listener quando a atividade for destruída
        if (salaListener != null) {
            salaListener.remove();
        }
    }
}
