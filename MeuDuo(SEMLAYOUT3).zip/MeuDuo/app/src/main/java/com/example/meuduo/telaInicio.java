package com.example.meuduo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class telaInicio extends AppCompatActivity {

    private EditText editTextEmail, editTextSenha;
    private Button btnLogin, btnCadastrar;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicio);

        // Inicializando as Views
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextSenha = findViewById(R.id.editTextSenha);
        btnLogin = findViewById(R.id.btnLogin);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        // Inicializando o FirebaseAuth
        mAuth = FirebaseAuth.getInstance();

        // Configurando o clique do botão de login
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextEmail.getText().toString().trim();
                String senha = editTextSenha.getText().toString().trim();

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(senha)) {
                    Toast.makeText(telaInicio.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    // Executar a tarefa de login em segundo plano
                    new LoginTask().execute(email, senha);
                }
            }
        });

        // Configurando o clique do botão de cadastrar
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Coloque aqui a lógica para abrir a tela de cadastro
                abrirTelaCadastro();
            }
        });
    }

    private class LoginTask extends AsyncTask<String, Void, Void> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            // Antes de fazer login, mostre um indicador de carregamento
            progressDialog = new ProgressDialog(telaInicio.this);
            progressDialog.setMessage("Entrando...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(String... params) {
            // Fazer login em segundo plano
            mAuth.signInWithEmailAndPassword(params[0], params[1])
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Login bem-sucedido
                                FirebaseUser user = mAuth.getCurrentUser();
                                // Redirecionar para a telaLobby passando o nome do usuário
                                if (user != null) {
                                    obterNomeUsuarioEIrParaTelaLobby(user.getUid());
                                }
                            } else {
                                // Se falhar, exiba uma mensagem ou lide com o erro
                                exibirMensagemFalha(task.getException().getMessage());
                            }
                        }
                    });
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            // Após o login ser concluído (onComplete), esconda o indicador
            progressDialog.dismiss();
        }
    }

    private void obterNomeUsuarioEIrParaTelaLobby(String userId) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("usuarios").document(userId)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String nomeUsuario = documentSnapshot.getString("usuario");
                            // Redirecionar para a telaLobby passando o nome do usuário
                            irParaTelaLobby(nomeUsuario);
                        } else {
                            Toast.makeText(telaInicio.this, "Documento do usuário não encontrado no Firestore", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(telaInicio.this, "Falha ao recuperar dados do usuário do Firestore", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void exibirMensagemFalha(String mensagem) {
        Toast.makeText(telaInicio.this, "Falha no login: " + mensagem, Toast.LENGTH_SHORT).show();
    }

    private void abrirTelaCadastro() {
        Intent intent = new Intent(this, telaCadastro.class);
        startActivity(intent);
    }

    private void irParaTelaLobby(String nomeUsuario) {
        Intent intent = new Intent(this, telaLobby.class);
        intent.putExtra("nomeUsuario", nomeUsuario);
        startActivity(intent);
        finish(); // Isso evita que o usuário retorne para esta tela pressionando o botão de voltar
    }
}
