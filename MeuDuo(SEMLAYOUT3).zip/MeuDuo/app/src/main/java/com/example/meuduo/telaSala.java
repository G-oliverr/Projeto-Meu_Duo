package com.example.meuduo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;

public class telaSala extends AppCompatActivity {

    private FirebaseFirestore db;
    private ListenerRegistration salaListener;
    private String salaId;
    private String idUsuarioCriador;

    private TextView textViewNomeSala;
    private TextView textViewNomeUsuarioCriador;
    private Button btnFecharSala;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_sala);

        db = FirebaseFirestore.getInstance();
        salaId = getIntent().getStringExtra("salaId");

        textViewNomeSala = findViewById(R.id.textViewNomeSala);
        textViewNomeUsuarioCriador = findViewById(R.id.textViewNomeUsuarioCriador);
        btnFecharSala = findViewById(R.id.btnFecharSala);

        // Adiciona um listener para atualizar os dados da sala
        salaListener = db.collection("salas").document(salaId)
                .addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            // Trate os erros aqui
                            return;
                        }

                        if (value != null && value.exists()) {
                            // Atualiza os TextViews com os dados da sala
                            String nomeSala = value.getString("nomeSala");
                            idUsuarioCriador = value.getString("idUsuarioCriador");

                            textViewNomeSala.setText(nomeSala);

                            // Obtém o nome do usuário criador
                            obterNomeUsuario(idUsuarioCriador);

                            // Habilita ou desabilita o botão de fechar sala com base no usuário atual
                            habilitarBotaoFechar(idUsuarioCriador);
                        }
                    }
                });

        // Adiciona um listener para o botão de fechar sala
        btnFecharSala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                excluirSala();
            }
        });
    }

    private void obterNomeUsuario(String idUsuario) {
        db.collection("usuarios").document(idUsuario)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            String nomeUsuarioCriador = document.getString("usuario");
                            textViewNomeUsuarioCriador.setText("Criada por: " + nomeUsuarioCriador);
                        }
                    }
                });
    }

    private void habilitarBotaoFechar(String idUsuarioCriador) {
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (usuarioAtual != null) {
            String idUsuarioAtual = usuarioAtual.getUid();

            // Verifica se o usuário atual é o criador da sala
            if (idUsuarioAtual.equals(idUsuarioCriador)) {
                btnFecharSala.setVisibility(View.VISIBLE);
            } else {
                btnFecharSala.setVisibility(View.GONE);
            }
        } else {
            // Se o usuário atual não estiver autenticado, você pode lidar com isso de acordo com seus requisitos
            // Por exemplo, redirecionar o usuário para a tela de login
            // ou exibir uma mensagem indicando que o usuário não está autenticado.
            btnFecharSala.setVisibility(View.GONE);
        }
    }

    private void excluirSala() {
        // Certifique-se de que o usuário que está tentando excluir é realmente o criador da sala
        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (usuarioAtual != null && usuarioAtual.getUid().equals(idUsuarioCriador)) {
            // Exclua a sala do Firestore
            db.collection("salas").document(salaId)
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        // Sala excluída com sucesso
                        // Você pode adicionar lógica adicional aqui, se necessário
                        finish(); // Encerra a atividade após excluir a sala
                    })
                    .addOnFailureListener(e -> {
                        // Trate falhas ao excluir a sala, se necessário
                    });
        } else {
            // Se o usuário atual não estiver autenticado ou não for o criador da sala,
            // você pode lidar com isso de acordo com seus requisitos
            // Por exemplo, exibindo uma mensagem informando que o usuário não tem permissão para excluir a sala.
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove o listener quando a atividade for destruída
        if (salaListener != null) {
            salaListener.remove();
        }
    }
}
